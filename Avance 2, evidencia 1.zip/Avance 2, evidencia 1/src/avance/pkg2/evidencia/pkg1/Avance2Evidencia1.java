package avance.pkg2.evidencia.pkg1;
import java.util.Scanner;
public class Avance2Evidencia1 {
    public static void main(String[] args) {
         Scanner leer = new Scanner(System.in);
         int id_unico, id_paciente, id_doc, id_cita, op;
         String nom_paciente, nom_doc, especialidad, motivo_cita, fecha_cita, hora_cita;
         System.out.println("Escoga una opción");
         System.out.println("1. Alta de Doctor");
         System.out.println("2. Alta paciente");
         System.out.println("3. Crear cita");
         op = leer.nextInt();
         
         if (op==1){
             System.out.println("Ingrese el id del Doctor");
             id_doc = leer.nextInt();
             System.out.println("Ingrese nombre completo del Doctor");
             nom_doc = leer.nextLine();
             System.out.println("Ingrese especialidad");
             especialidad = leer.nextLine();
             System.out.println("¡Alta exitosa!");
         }
         
         if (op==2){
             System.out.println("Ingrese el id del paciente");
             id_paciente = leer.nextInt();
             System.out.println("Ingrese nombre completo del paciente");  
             nom_paciente = leer.nextLine();
             System.out.println("¡Alta exitosa!");            
         }
         
         if (op==3){
             System.out.println("Ingrese id de la cita");
             id_cita = leer.nextInt();
             System.out.println("Ingrese fecha de la cita");
             fecha_cita = leer.nextLine();
             System.out.println("Ingrese hora de la cita");
             hora_cita = leer.nextLine();
             System.out.println("Ingrese motivo de la cita");
             motivo_cita = leer.nextLine();
             System.out.println("¡Cita registrada!");            
         }      
    } 
}
