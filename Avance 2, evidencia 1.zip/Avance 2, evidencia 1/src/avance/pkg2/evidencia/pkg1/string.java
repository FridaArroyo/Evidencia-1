/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avance.pkg2.evidencia.pkg1;

/**
 *
 * @author frida
 */
class string {
    
}
